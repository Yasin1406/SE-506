public abstract class Device {
    public abstract void powerOn();
    public abstract void powerOff();
}
