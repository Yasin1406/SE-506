public interface DeviceFactory {
    Device createDevice();
}
